﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{
    public float speed;
    Rigidbody PlayerRigidbody;
    // Start is called before the first frame update
    void Start()
    {
        PlayerRigidbody = GetComponent<Rigidbody>();
    }
    private void FixedUpdate()
    {
        float moveHori = Input.GetAxis("Horizontal");
        float moveVert = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHori, 0, moveVert);
        PlayerRigidbody.AddForce(movement * speed * Time.deltaTime);
    }
    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Finish")
        {
            Destroy(collision.gameObject);
            Debug.Log("bluh");
            PlayerPrefs.SetFloat("coin", PlayerPrefs.GetFloat("coin", 0)+1);
        }
        if (collision.gameObject.tag == "Respawn")
        {

            SceneManager.LoadScene(2);
        }
    }
}
