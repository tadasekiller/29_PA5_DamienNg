﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class CoinUI : MonoBehaviour
{
    Text cointxt;
    // Start is called before the first frame update
    void Start()
    {
        cointxt = GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        cointxt.text = "Coins: " + PlayerPrefs.GetFloat("coin", 0) + "/10";
    }
}
